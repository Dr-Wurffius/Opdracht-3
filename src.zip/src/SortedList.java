import java.util.LinkedList;

/**
 * Created by Martijn on 18-05-16.
 */
public class SortedList
{
    private Vak start;
    private Vak end;
    private Vak temp;
    private int size;


    public boolean push(Vak v)
    {
        if(start == null && end == null)
        {
            start = v;
            end = v;
        }
        else
        {
            start.setPreviousVak(v);
            v.setNextVak(start);
            start = v;
        }
        size++;
        return true;
    }


    public int size()
    {
        System.out.println("De grote van de list is: " + size);
        return size;
    }

    public double berekenGemiddeldeCijfers()
    {
        temp = start;

        int count               = size;
        int cummelatiefCijfer   = 0;


        while (count != 0)
        {
            cummelatiefCijfer =+ temp.getCijfer();


            count--;
            temp.getNextVak();
        }

        return (cummelatiefCijfer/size);

    }

    public Vak head()
    {
        //retourneert de eerste student in de list en verwijdert dez uit de list

        System.out.println("De eerst toegevoegde student wordt verwijderd");
        System.out.println("---------------------------------------------");
        start.printVak();
        start = start.getNextVak();
        start.setPreviousVak(null);
        size--;

        return start;
    }

    public Vak tail()
    {
        //retourneert de laatste student in de list en verwijderd deze uit de list


        System.out.println("De laatste toegevoegde student wordt verwijderd");
        System.out.println("-----------------------------------------------");
        end.printVak();
        end = end.getPreviousVak();
        end.setNextVak(null);
        size--;

        return end;


    }

    public Vak pop(int index)
    {
        //retourneert student s ui de List op positie index en verwijdert deze uit de list
        int count = size;
        temp = start;

        System.out.println("Student op plaats " + index + " wordt verwijderd" );
        System.out.println("------------------------------------------------");


        if(index <= 1)
        {
            size--;
            return head();

        } else if (index > size)
        {
            size--;
            return tail();
        }
        else
        {
            for (int i = 1; i < index; i++)
            {
                temp = temp.getNextVak();
            }

            temp.printVak();

            temp.getNextVak().setPreviousVak(temp.getPreviousVak());
            temp.getPreviousVak().setNextVak(temp.getNextVak());
            size--;

            return temp;



        }

    }

    public boolean peek(Vak s)
    {
        temp = start;

        int count = size;

        while (count != 0)
        {
            if(s.getModulecode() == temp.getModulecode())
            {
                System.out.println("Studennummer " + s.getModulecode() + " is aanwezig");
                return true;
            }
            temp = temp.getNextVak();
            count --;

        }

        return false;

    }

    public void printList()
    {
        Vak print = start;
        int counter = size;

        System.out.println();
        System.out.println("de List wordt geprint.");
        System.out.println("-----------------------");

        while (counter != 0)
        {
            print.printVak();
            print = print.getNextVak();
            counter--;

        }




    }

//    public void printMen()
//    {
//        Va possibleMan = start;
//        int counter         = size;
//        int menCount        = 0;
//
//        System.out.println("Alle mannelijke studenten worden geprint.");
//        System.out.println("-----------------------------------------");
//
//        while (counter != 0)
//        {
//            if (possibleMan.getGeslacht() == 'm')
//            {
//
//                possibleMan.printStudent();
//                menCount++;
//            }
//
//            possibleMan = possibleMan.getNextVak();
//            counter--;
//
//        }
//
//        System.out.println("Totaal aantal mannen: " + menCount);
//        System.out.println();
//
//
//    }
//
//    public void printWomen()
//    {
//        Student possibleWoman = start;
//        int counter             = size;
//        int womenCount        = 0;
//
//        System.out.println("Alle vrouwlijke studenten worden geprint.");
//        System.out.println("-----------------------------------------");
//
//        while (counter != 0)
//        {
//            if (possibleWoman.getGeslacht() == 'v')
//            {
//
//                possibleWoman.printStudent();
//                womenCount++;
//            }
//
//            possibleWoman = possibleWoman.getNextVak();
//            counter--;
//
//        }
//
//        System.out.println("Totaal aantal vrouwenlijke studenten: " + womenCount);
//        System.out.println();
//
//    }

}
