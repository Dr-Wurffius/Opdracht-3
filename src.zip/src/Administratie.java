import java.util.HashMap;

/**
 * Created by Martijn on 13-06-16.
 */
public class Administratie
{
    private HashMap student;
    private int     totaalAantalStudenten;


    public void printStudentenVakGehaald()
    {

    }

    public void gemiddeldeVak()
    {

    }

    public void behaaldeVakkenStudent()
    {

    }

    public void nogTeBehalenVakkenStudent()
    {

    }

    public void gemiddeldeCijfer()
    {

    }




}
